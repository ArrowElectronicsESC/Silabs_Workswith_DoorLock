/*
 * Init_g.h
 *
 *  Created on: July 10, 2020
 *      Author: prassanna.sakore
 */

#ifndef INIT_G_H_
#define INIT_G_H_

void StartPeripherals(void);
void InitVariables(void) ;
void InitPeripherals(void) ;

#endif /* INIT_G_H_ */
