/*
 * Gvar.h
 *
 *  Created on: July 10, 2020
 *      Author: prassanna.sakore
 */

#ifndef GVAR_H_
#define GVAR_H_

TagButton Button ;
TagUsers Users ;


#endif /* GVAR_H_ */
