/*
 * Timer_g.h
 *
 *  Created on: July 10, 2020
 *      Author: prassanna.sakore
 */

#ifndef TIMER_G_H_
#define TIMER_G_H_

void InitTimer0(void) ;
void InitTimer1(void) ;

#endif /* TIMER_G_H_ */
