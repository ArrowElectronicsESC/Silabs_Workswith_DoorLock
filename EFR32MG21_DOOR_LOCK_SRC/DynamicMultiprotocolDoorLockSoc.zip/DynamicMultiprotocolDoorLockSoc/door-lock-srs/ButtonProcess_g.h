/*
 * ButtonProcess_g.h
 *
 *  Created on: July 10, 2020
 *      Author: prassanna.sakore
 */

#ifndef BUTTONPROCESS_G_H_
#define BUTTONPROCESS_G_H_

void CheckButton(void);

#endif /* BUTTONPROCESS_G_H_ */
