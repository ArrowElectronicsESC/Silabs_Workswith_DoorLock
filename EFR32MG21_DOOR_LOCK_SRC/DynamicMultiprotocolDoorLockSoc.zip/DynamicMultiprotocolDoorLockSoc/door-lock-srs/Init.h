/*
 * Init.h
 *
 *  Created on: July 10, 2020
 *      Author: prassanna.sakore
 */

#ifndef INIT_H_
#define INIT_H_

void initCMU(void) ;

#endif /* INIT_H_ */
