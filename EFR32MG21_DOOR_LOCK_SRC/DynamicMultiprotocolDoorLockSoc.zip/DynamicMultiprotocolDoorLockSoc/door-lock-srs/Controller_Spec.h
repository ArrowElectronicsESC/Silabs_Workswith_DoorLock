/*
 * Controller_Spec.h
 *
 *  Created on: July 10, 2020
 *      Author: prassanna.sakore
 */

#ifndef CONTROLLER_SPEC_H_
#define CONTROLLER_SPEC_H_

#define MICRO_SEC_IN_SEC_COUNT 80 //For 80 MHz

#endif /* CONTROLLER_SPEC_H_ */



