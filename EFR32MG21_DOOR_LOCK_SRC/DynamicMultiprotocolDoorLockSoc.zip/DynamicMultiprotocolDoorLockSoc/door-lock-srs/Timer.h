/*
 * Timer.h
 *
 *  Created on: July 10, 2020
 *      Author: prassanna.sakore
 */

#ifndef TIMER_H_
#define TIMER_H_

#define TIMER_0_PERIOD_Sec (0.001)

#define TIMER_1_PERIOD_Sec (0.001)

#endif /* TIMER_H_ */
