/*
 * I2C.h
 *
 *  Created on: July 15, 2020
 *      Author: prassanna.sakore
 */

#ifndef I2C_H_
#define I2C_H_

#ifdef KEYPAD_I2C


#endif

#endif /* I2C_H_ */
